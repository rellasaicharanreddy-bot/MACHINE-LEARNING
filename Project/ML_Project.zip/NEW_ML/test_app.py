import urllib.request
import json
import subprocess
import time
import sys

print("[Test] Launching app.py...")
proc = subprocess.Popen([sys.executable, "app.py"], cwd=r"C:\Users\ADMIN\OneDrive\Desktop\sports-injury-app\NEW_ML")
time.sleep(2)

try:
    print("[Test] Fetching /api/status...")
    with urllib.request.urlopen("http://localhost:5000/api/status") as res:
        print("Status Code:", res.status)
        print("Response:", res.read().decode("utf-8"))

    print("\n[Test] Testing /api/predict (POST)...")
    payload = json.dumps({
        "Age": 22,
        "Gender": "Male",
        "Sport": "Soccer",
        "BMI": 23.5,
        "Training_Hours_Per_Week": 27.0,
        "Previous_Injuries": 2,
        "Fatigue_Score": 8,
        "Sleep_Hours": 5.5,
        "Warmup_Duration_Min": 10,
        "Hydration_Level_Liters": 2.0,
        "Training_Intensity": "High",
        "Recovery_Days": 1,
        "Muscle_Soreness": 7
    }).encode("utf-8")

    req = urllib.request.Request("http://localhost:5000/api/predict", data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as res:
        print("Predict Status:", res.status)
        print("Predict Result:", res.read().decode("utf-8")[:300] + "...")

    print("\n[Test] SUCCESS! All endpoints working properly.")
finally:
    proc.terminate()
    proc.wait()
    print("[Test] Server stopped cleanly.")
