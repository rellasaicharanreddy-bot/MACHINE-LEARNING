@echo off
title Sports Injury Risk Prediction - Random Forest & SVM
echo ========================================================
echo   SPORTS INJURY RISK PREDICTION (RANDOM FOREST & SVM)
echo ========================================================
echo.
echo Checking training artifacts...
if not exist "models\metrics.json" (
    echo [Setup] Training models for the first time...
    python src\train.py
)
echo.
echo [Starting] Launching web application on http://localhost:5000 ...
start "" "http://localhost:5000"
python app.py
pause
