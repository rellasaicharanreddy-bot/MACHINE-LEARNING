"""
Machine Learning Core: Random Forest & Support Vector Machine (SVM)
Supports:
1. Production Scikit-Learn Engine (if sklearn installed)
2. Standalone Pure-Python Mathematical Engine (Zero-Dependency fallback)
Ensures 100% immediate execution on any environment with full mathematical rigor.
"""

import math
import random
import json
import os

# Check if scikit-learn is available
SKLEARN_AVAILABLE = False
try:
    from sklearn.ensemble import RandomForestClassifier as SklearnRF
    from sklearn.svm import SVC as SklearnSVC
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score
    import joblib
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# ==============================================================================
# EVALUATION METRICS CALCULATOR
# ==============================================================================

def compute_metrics(y_true, y_pred, y_prob=None):
    tp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 1)
    tn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 0)
    fp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 0 and yp == 1)
    fn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 0)

    total = len(y_true)
    accuracy = (tp + tn) / total if total > 0 else 0.0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0

    # Approximate ROC-AUC via rank-sum or probabilities if provided
    auc = 0.5
    if y_prob is not None:
        pos_scores = [prob for yt, prob in zip(y_true, y_prob) if yt == 1]
        neg_scores = [prob for yt, prob in zip(y_true, y_prob) if yt == 0]
        if pos_scores and neg_scores:
            wins = sum(1.0 if p > n else (0.5 if p == n else 0.0) for p in pos_scores for n in neg_scores)
            auc = wins / (len(pos_scores) * len(neg_scores))
    else:
        auc = (recall + (tn / (tn + fp) if (tn + fp) > 0 else 0.0)) / 2.0

    return {
        "accuracy": round(accuracy * 100, 2),
        "precision": round(precision * 100, 2),
        "recall": round(recall * 100, 2),
        "f1_score": round(f1 * 100, 2),
        "roc_auc": round(auc * 100, 2),
        "confusion_matrix": {
            "tp": tp,
            "tn": tn,
            "fp": fp,
            "fn": fn
        }
    }


# ==============================================================================
# PURE PYTHON RANDOM FOREST CLASSIFIER (Zero-Dependency Engine)
# ==============================================================================

class DecisionNode:
    def __init__(self, feature_idx=None, threshold=None, left=None, right=None, value=None):
        self.feature_idx = feature_idx
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value  # Leaf probability of class 1

    @property
    def is_leaf(self):
        return self.value is not None


class PureDecisionTree:
    def __init__(self, max_depth=6, min_samples_split=4, max_features=None):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.root = None

    def _gini(self, y):
        n = len(y)
        if n == 0:
            return 0.0
        p1 = sum(y) / n
        p0 = 1.0 - p1
        return 1.0 - (p0 ** 2 + p1 ** 2)

    def _best_split(self, X, y, feature_indices):
        best_gain = -1.0
        best_feat = None
        best_thresh = None
        current_gini = self._gini(y)

        n = len(y)
        for feat in feature_indices:
            # Sample percentiles or unique values for speed
            vals = [X[i][feat] for i in range(n)]
            unique_vals = sorted(set(vals))
            if len(unique_vals) <= 1:
                continue

            # Check candidate thresholds (up to 15 midpoints)
            step = max(1, len(unique_vals) // 15)
            candidates = [(unique_vals[i] + unique_vals[i+1]) / 2.0 for i in range(0, len(unique_vals)-1, step)]

            for thresh in candidates:
                left_y = [y[i] for i in range(n) if X[i][feat] <= thresh]
                right_y = [y[i] for i in range(n) if X[i][feat] > thresh]

                if len(left_y) == 0 or len(right_y) == 0:
                    continue

                w_gini = (len(left_y) / n) * self._gini(left_y) + (len(right_y) / n) * self._gini(right_y)
                gain = current_gini - w_gini
                if gain > best_gain:
                    best_gain = gain
                    best_feat = feat
                    best_thresh = thresh

        return best_feat, best_thresh, best_gain

    def _build_tree(self, X, y, depth=0):
        n_samples = len(y)
        n_features = len(X[0]) if n_samples > 0 else 0

        # Base conditions: pure node, max depth, or min samples
        p1 = sum(y) / n_samples if n_samples > 0 else 0.5
        if depth >= self.max_depth or n_samples < self.min_samples_split or p1 == 0.0 or p1 == 1.0:
            return DecisionNode(value=p1)

        # Feature subsampling
        m = self.max_features or max(1, int(math.sqrt(n_features)))
        feature_indices = random.sample(range(n_features), min(m, n_features))

        feat, thresh, gain = self._best_split(X, y, feature_indices)
        if feat is None or gain <= 1e-5:
            return DecisionNode(value=p1)

        left_idx = [i for i in range(n_samples) if X[i][feat] <= thresh]
        right_idx = [i for i in range(n_samples) if X[i][feat] > thresh]

        left_child = self._build_tree([X[i] for i in left_idx], [y[i] for i in left_idx], depth + 1)
        right_child = self._build_tree([X[i] for i in right_idx], [y[i] for i in right_idx], depth + 1)

        return DecisionNode(feature_idx=feat, threshold=thresh, left=left_child, right=right_child)

    def fit(self, X, y):
        self.root = self._build_tree(X, y)

    def _predict_prob_sample(self, node, x):
        if node.is_leaf:
            return node.value
        if x[node.feature_idx] <= node.threshold:
            return self._predict_prob_sample(node.left, x)
        return self._predict_prob_sample(node.right, x)

    def predict_proba(self, X):
        return [self._predict_prob_sample(self.root, x) for x in X]


class PureRandomForestClassifier:
    def __init__(self, n_estimators=30, max_depth=6, min_samples_split=4, seed=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.seed = seed
        self.trees = []
        self.feature_importances_ = []

    def fit(self, X, y):
        random.seed(self.seed)
        self.trees = []
        n_samples = len(X)
        n_features = len(X[0])
        importance_counts = [0.0] * n_features

        for _ in range(self.n_estimators):
            # Bootstrap sampling with replacement
            boot_idx = [random.randint(0, n_samples - 1) for _ in range(n_samples)]
            X_boot = [X[i] for i in boot_idx]
            y_boot = [y[i] for i in boot_idx]

            tree = PureDecisionTree(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split
            )
            tree.fit(X_boot, y_boot)
            self.trees.append(tree)

            # Accumulate feature usage
            self._accumulate_importances(tree.root, importance_counts)

        # Normalize feature importances
        total_imp = sum(importance_counts)
        if total_imp > 0:
            self.feature_importances_ = [round(c / total_imp, 4) for c in importance_counts]
        else:
            self.feature_importances_ = [1.0 / n_features] * n_features

    def _accumulate_importances(self, node, counts):
        if node is None or node.is_leaf:
            return
        counts[node.feature_idx] += 1.0
        self._accumulate_importances(node.left, counts)
        self._accumulate_importances(node.right, counts)

    def predict_proba(self, X):
        all_probs = [tree.predict_proba(X) for tree in self.trees]
        n_samples = len(X)
        avg_probs = []
        for i in range(n_samples):
            p = sum(all_probs[t][i] for t in range(len(self.trees))) / len(self.trees)
            avg_probs.append(p)
        return avg_probs

    def predict(self, X, threshold=0.5):
        probs = self.predict_proba(X)
        return [1 if p >= threshold else 0 for p in probs]

    def to_dict(self):
        def node_to_dict(n):
            if n is None:
                return None
            return {
                "feat": n.feature_idx,
                "thresh": n.threshold,
                "val": n.value,
                "left": node_to_dict(n.left),
                "right": node_to_dict(n.right)
            }
        return {
            "n_estimators": self.n_estimators,
            "max_depth": self.max_depth,
            "feature_importances": self.feature_importances_,
            "trees": [node_to_dict(t.root) for t in self.trees]
        }

    def from_dict(self, d):
        self.n_estimators = d["n_estimators"]
        self.max_depth = d["max_depth"]
        self.feature_importances_ = d.get("feature_importances", [])
        
        def dict_to_node(cd):
            if cd is None:
                return None
            node = DecisionNode(
                feature_idx=cd["feat"],
                threshold=cd["thresh"],
                value=cd["val"]
            )
            node.left = dict_to_node(cd["left"])
            node.right = dict_to_node(cd["right"])
            return node

        self.trees = []
        for td in d["trees"]:
            tree = PureDecisionTree(max_depth=self.max_depth)
            tree.root = dict_to_node(td)
            self.trees.append(tree)


# ==============================================================================
# PURE PYTHON SUPPORT VECTOR MACHINE (SVM) CLASSIFIER (RBF Kernel & Platt Scaling)
# ==============================================================================

class PureSVMClassifier:
    """
    Support Vector Machine with Radial Basis Function (RBF) Kernel.
    Trained via Pegasos / Kernel Perceptron dual representation with Platt Sigmoid Probability Scaling.
    """
    def __init__(self, C=1.5, gamma=0.08, epochs=12, seed=42):
        self.C = C
        self.gamma = gamma
        self.epochs = epochs
        self.seed = seed
        self.support_vectors = []
        self.alpha_y = []
        self.bias = 0.0
        self.platt_a = -1.5
        self.platt_b = 0.0

    def _rbf_kernel(self, x1, x2):
        sq_dist = sum((a - b) ** 2 for a, b in zip(x1, x2))
        return math.exp(-self.gamma * sq_dist)

    def fit(self, X, y):
        random.seed(self.seed)
        n = len(X)
        # Convert {0, 1} targets to {-1, +1}
        y_pm = [1 if val == 1 else -1 for val in y]

        # Dual weights (alphas * y)
        weights = [0.0] * n
        b = 0.0

        # Subgradient SGD on soft-margin dual objective
        step_indices = list(range(n))
        for epoch in range(1, self.epochs + 1):
            lr = 1.0 / (epoch * 0.4)
            random.shuffle(step_indices)
            for i in step_indices:
                # Compute current kernel decision function f(x_i)
                f_i = b
                for j in range(n):
                    if abs(weights[j]) > 1e-5:
                        f_i += weights[j] * self._rbf_kernel(X[j], X[i])

                # Hinge loss violation check: y_i * f(x_i) < 1
                if y_pm[i] * f_i < 1.0:
                    delta = lr * y_pm[i] * self.C
                    weights[i] = max(-self.C, min(self.C, weights[i] + delta))
                    b += lr * y_pm[i] * 0.1

        # Extract non-zero support vectors
        self.support_vectors = []
        self.alpha_y = []
        for i in range(n):
            if abs(weights[i]) > 1e-4:
                self.support_vectors.append(X[i])
                self.alpha_y.append(round(weights[i], 5))

        self.bias = round(b, 5)

        # Calibrate Platt probability scaling
        raw_scores = [self._decision_function_single(x) for x in X]
        self._fit_platt_scaling(raw_scores, y)

    def _decision_function_single(self, x):
        score = self.bias
        for sv, ay in zip(self.support_vectors, self.alpha_y):
            score += ay * self._rbf_kernel(sv, x)
        return score

    def _fit_platt_scaling(self, scores, y):
        # Logistic regression on decision scores to map distance to probability
        # Minimize negative log likelihood using gradient descent
        a = -1.8
        b = 0.0
        lr = 0.05
        for _ in range(80):
            grad_a = 0.0
            grad_b = 0.0
            for score, target in zip(scores, y):
                z = a * score + b
                p = 1.0 / (1.0 + math.exp(-max(-12.0, min(12.0, z))))
                error = p - target
                grad_a += error * score
                grad_b += error
            a -= lr * (grad_a / len(scores))
            b -= lr * (grad_b / len(scores))
        self.platt_a = round(a, 4)
        self.platt_b = round(b, 4)

    def decision_function(self, X):
        return [self._decision_function_single(x) for x in X]

    def predict_proba(self, X):
        scores = self.decision_function(X)
        probs = []
        for s in scores:
            z = self.platt_a * s + self.platt_b
            prob = 1.0 / (1.0 + math.exp(-max(-15.0, min(15.0, z))))
            probs.append(prob)
        return probs

    def predict(self, X, threshold=0.5):
        probs = self.predict_proba(X)
        return [1 if p >= threshold else 0 for p in probs]

    def to_dict(self):
        return {
            "C": self.C,
            "gamma": self.gamma,
            "bias": self.bias,
            "platt_a": self.platt_a,
            "platt_b": self.platt_b,
            "num_support_vectors": len(self.support_vectors),
            "alpha_y": self.alpha_y,
            "support_vectors": self.support_vectors
        }

    def from_dict(self, d):
        self.C = d["C"]
        self.gamma = d["gamma"]
        self.bias = d["bias"]
        self.platt_a = d["platt_a"]
        self.platt_b = d["platt_b"]
        self.alpha_y = d["alpha_y"]
        self.support_vectors = d["support_vectors"]


# ==============================================================================
# UNIFIED MODEL WRAPPER
# ==============================================================================

class SportsInjuryModelManager:
    def __init__(self, use_sklearn=SKLEARN_AVAILABLE):
        self.use_sklearn = use_sklearn
        self.rf_model = None
        self.svm_model = None
        self.metrics = {}
        self.feature_names = []

    def train_models(self, X_train, y_train, X_test, y_test, feature_names):
        self.feature_names = feature_names
        print(f"[Training] Mode: {'Scikit-Learn Production' if self.use_sklearn else 'Standalone Math Engine'}")
        
        # 1. Random Forest Training
        print("[Training] Training Random Forest Classifier...")
        if self.use_sklearn:
            self.rf_model = SklearnRF(n_estimators=100, max_depth=8, min_samples_split=4, random_state=42)
            self.rf_model.fit(X_train, y_train)
            rf_test_pred = self.rf_model.predict(X_test)
            rf_test_prob = self.rf_model.predict_proba(X_test)[:, 1]
            rf_importances = [round(float(v), 4) for v in self.rf_model.feature_importances_]
        else:
            self.rf_model = PureRandomForestClassifier(n_estimators=35, max_depth=6, min_samples_split=4)
            self.rf_model.fit(X_train, y_train)
            rf_test_pred = self.rf_model.predict(X_test)
            rf_test_prob = self.rf_model.predict_proba(X_test)
            rf_importances = self.rf_model.feature_importances_

        rf_metrics = compute_metrics(y_test, rf_test_pred, rf_test_prob)
        rf_metrics["feature_importances"] = dict(zip(feature_names, rf_importances))

        # 2. Support Vector Machine Training
        print("[Training] Training Support Vector Machine (SVM) Classifier with RBF Kernel...")
        if self.use_sklearn:
            self.svm_model = SklearnSVC(C=1.5, kernel='rbf', gamma='scale', probability=True, random_state=42)
            self.svm_model.fit(X_train, y_train)
            svm_test_pred = self.svm_model.predict(X_test)
            svm_test_prob = self.svm_model.predict_proba(X_test)[:, 1]
        else:
            self.svm_model = PureSVMClassifier(C=1.5, gamma=0.08, epochs=12)
            self.svm_model.fit(X_train, y_train)
            svm_test_pred = self.svm_model.predict(X_test)
            svm_test_prob = self.svm_model.predict_proba(X_test)

        svm_metrics = compute_metrics(y_test, svm_test_pred, svm_test_prob)

        self.metrics = {
            "random_forest": rf_metrics,
            "svm": svm_metrics,
            "dataset_info": {
                "train_samples": len(X_train),
                "test_samples": len(X_test),
                "num_features": len(feature_names)
            }
        }

        print("\n" + "="*50)
        print("MODEL EVALUATION & COMPARISON SUMMARY")
        print("="*50)
        print(f"{'Metric':<20} | {'Random Forest':<15} | {'SVM':<15}")
        print("-"*50)
        for m in ["accuracy", "precision", "recall", "f1_score", "roc_auc"]:
            print(f"{m.capitalize():<20} | {rf_metrics[m]:>13}% | {svm_metrics[m]:>13}%")
        print("="*50)
        return self.metrics

    def predict_single(self, scaled_vector):
        """Generates predictions from both RF and SVM for a single athlete vector."""
        if self.use_sklearn:
            rf_prob = float(self.rf_model.predict_proba([scaled_vector])[0][1])
            rf_pred = int(self.rf_model.predict([scaled_vector])[0])
            svm_prob = float(self.svm_model.predict_proba([scaled_vector])[0][1])
            svm_pred = int(self.svm_model.predict([scaled_vector])[0])
        else:
            rf_prob = float(self.rf_model.predict_proba([scaled_vector])[0])
            rf_pred = 1 if rf_prob >= 0.50 else 0
            svm_prob = float(self.svm_model.predict_proba([scaled_vector])[0])
            svm_pred = 1 if svm_prob >= 0.50 else 0

        # Consensus ensemble probability
        ensemble_prob = round((rf_prob * 0.55 + svm_prob * 0.45) * 100, 1)

        # Risk categorization
        if ensemble_prob < 35.0:
            risk_category = "Low Risk"
            risk_color = "#10b981"  # Emerald Green
        elif ensemble_prob < 65.0:
            risk_category = "Moderate Risk"
            risk_color = "#f59e0b"  # Amber
        else:
            risk_category = "High Risk"
            risk_color = "#ef4444"  # Red

        return {
            "random_forest": {
                "prediction": rf_pred,
                "label": "High Risk" if rf_pred == 1 else "Low Risk",
                "probability": round(rf_prob * 100, 1)
            },
            "svm": {
                "prediction": svm_pred,
                "label": "High Risk" if svm_pred == 1 else "Low Risk",
                "probability": round(svm_prob * 100, 1)
            },
            "ensemble": {
                "risk_score_percent": ensemble_prob,
                "risk_category": risk_category,
                "risk_color": risk_color
            }
        }

    def save(self, models_dir):
        os.makedirs(models_dir, exist_ok=True)
        # Save metrics
        with open(os.path.join(models_dir, "metrics.json"), "w", encoding="utf-8") as f:
            json.dump(self.metrics, f, indent=2)

        if self.use_sklearn:
            joblib.dump(self.rf_model, os.path.join(models_dir, "rf_model.pkl"))
            joblib.dump(self.svm_model, os.path.join(models_dir, "svm_model.pkl"))
        else:
            with open(os.path.join(models_dir, "rf_model.json"), "w", encoding="utf-8") as f:
                json.dump(self.rf_model.to_dict(), f)
            with open(os.path.join(models_dir, "svm_model.json"), "w", encoding="utf-8") as f:
                json.dump(self.svm_model.to_dict(), f)
        print(f"[Model Manager] All models and metrics saved to: {models_dir}")

    def load(self, models_dir):
        metrics_file = os.path.join(models_dir, "metrics.json")
        if os.path.exists(metrics_file):
            with open(metrics_file, "r", encoding="utf-8") as f:
                self.metrics = json.load(f)

        if self.use_sklearn and os.path.exists(os.path.join(models_dir, "rf_model.pkl")):
            self.rf_model = joblib.load(os.path.join(models_dir, "rf_model.pkl"))
            self.svm_model = joblib.load(os.path.join(models_dir, "svm_model.pkl"))
        else:
            rf_json = os.path.join(models_dir, "rf_model.json")
            if os.path.exists(rf_json):
                with open(rf_json, "r", encoding="utf-8") as f:
                    d = json.load(f)
                self.rf_model = PureRandomForestClassifier()
                self.rf_model.from_dict(d)

            svm_json = os.path.join(models_dir, "svm_model.json")
            if os.path.exists(svm_json):
                with open(svm_json, "r", encoding="utf-8") as f:
                    d = json.load(f)
                self.svm_model = PureSVMClassifier()
                self.svm_model.from_dict(d)
        print("[Model Manager] Models loaded successfully.")
