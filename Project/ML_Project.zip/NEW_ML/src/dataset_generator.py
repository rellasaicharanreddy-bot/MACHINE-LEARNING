"""
Sports Injury Risk Dataset Generator
Generates realistic multi-feature sports biomechanics and training load data.
Correlated with clinical sports medicine injury incidence factors.
"""

import csv
import math
import os
import random

def generate_sports_injury_dataset(output_path, num_samples=1500, seed=42):
    random.seed(seed)
    
    sports_list = ["Football", "Soccer", "Basketball", "Running", "Tennis", "Rugby", "Cricket"]
    genders = ["Male", "Female"]
    intensities = ["Low", "Medium", "High"]
    
    headers = [
        "Athlete_ID",
        "Age",
        "Gender",
        "Sport",
        "BMI",
        "Training_Hours_Per_Week",
        "Previous_Injuries",
        "Fatigue_Score",
        "Sleep_Hours",
        "Warmup_Duration_Min",
        "Hydration_Level_Liters",
        "Training_Intensity",
        "Recovery_Days",
        "Muscle_Soreness",
        "Injury_Risk"
    ]
    
    rows = []
    
    for i in range(1, num_samples + 1):
        athlete_id = f"ATH_{i:04d}"
        age = random.randint(17, 36)
        gender = random.choice(genders)
        sport = random.choice(sports_list)
        
        # BMI between 19.0 and 32.5
        bmi = round(random.gauss(24.5, 2.8), 1)
        bmi = max(18.5, min(34.0, bmi))
        
        # Training hours: typically 8 to 32 hours/week
        training_hours = round(random.uniform(6.0, 32.0), 1)
        
        # Previous injuries (0 to 4)
        prev_injuries = random.choices([0, 1, 2, 3, 4], weights=[0.42, 0.28, 0.16, 0.10, 0.04])[0]
        
        # Fatigue score: 1 to 10
        # Correlated with high training hours
        base_fatigue = 2.0 + (training_hours / 32.0) * 5.0 + random.uniform(-1.5, 2.0)
        fatigue_score = int(round(max(1, min(10, base_fatigue))))
        
        # Sleep hours: 4.5 to 9.5
        sleep_hours = round(random.gauss(7.2, 1.1), 1)
        sleep_hours = max(4.0, min(10.0, sleep_hours))
        
        # Warmup duration: 5 to 30 mins
        warmup_min = int(round(random.gauss(16.0, 6.0)))
        warmup_min = max(0, min(35, warmup_min))
        
        # Hydration level: 1.2 to 4.5 liters
        hydration = round(random.gauss(2.7, 0.7), 1)
        hydration = max(1.0, min(5.0, hydration))
        
        # Intensity
        intensity = random.choices(intensities, weights=[0.25, 0.45, 0.30])[0]
        
        # Recovery days per week: 0 to 4
        recovery_days = random.choices([0, 1, 2, 3, 4], weights=[0.12, 0.35, 0.35, 0.13, 0.05])[0]
        
        # Muscle soreness: 1 to 10
        base_soreness = (fatigue_score * 0.5) + (1.5 if intensity == "High" else (0.5 if intensity == "Medium" else 0)) + (2.0 if recovery_days <= 1 else 0) + random.uniform(-1.0, 1.5)
        muscle_soreness = int(round(max(1, min(10, base_soreness))))
        
        # Sport-specific injury baseline factor
        sport_risk_factor = {
            "Rugby": 1.25,
            "Football": 1.20,
            "Soccer": 1.10,
            "Basketball": 1.05,
            "Running": 0.95,
            "Tennis": 0.85,
            "Cricket": 0.80
        }.get(sport, 1.0)
        
        # Calculate latent Risk Probability (Log-odds sigmoid function)
        z = -1.1  # baseline bias for balanced realistic sports injury distribution
        z += 0.08 * (training_hours - 18.0)
        z += 0.55 * prev_injuries
        z += 0.35 * (fatigue_score - 5.0)
        z -= 0.45 * (sleep_hours - 7.0)
        z -= 0.07 * (warmup_min - 15.0)
        z -= 0.35 * (hydration - 2.5)
        z += 0.70 * (1 if intensity == "High" else (-0.5 if intensity == "Low" else 0))
        z -= 0.45 * (recovery_days - 1.5)
        z += 0.30 * (muscle_soreness - 5.0)
        z += 0.08 * (bmi - 24.0)
        z *= sport_risk_factor
        
        # Sigmoid
        prob = 1.0 / (1.0 + math.exp(-max(-10.0, min(10.0, z))))
        
        # Assign risk class with realistic threshold + slight stochasticity
        injury_risk = 1 if (prob + random.uniform(-0.08, 0.08)) >= 0.50 else 0
        
        rows.append([
            athlete_id,
            age,
            gender,
            sport,
            bmi,
            training_hours,
            prev_injuries,
            fatigue_score,
            sleep_hours,
            warmup_min,
            hydration,
            intensity,
            recovery_days,
            muscle_soreness,
            injury_risk
        ])
        
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)
        
    print(f"[Dataset Generator] Successfully generated {len(rows)} records at: {output_path}")
    high_risk_count = sum(1 for r in rows if r[-1] == 1)
    print(f"[Dataset Generator] Class Distribution: Low Risk = {len(rows)-high_risk_count} ({(len(rows)-high_risk_count)/len(rows)*100:.1f}%), High Risk = {high_risk_count} ({high_risk_count/len(rows)*100:.1f}%)")
    return output_path

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_csv = os.path.join(current_dir, "..", "data", "sports_injury_dataset.csv")
    generate_sports_injury_dataset(target_csv)
