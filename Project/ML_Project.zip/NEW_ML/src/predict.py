"""
Inference & Clinical Recommendation Engine
Predicts injury risk using Random Forest and SVM.
Generates personalized injury prevention and load management recommendations.
"""

import os
import sys
import json

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from preprocessor import DataPreprocessor
from models import SportsInjuryModelManager

class InjuryPredictor:
    def __init__(self, models_dir=None):
        if models_dir is None:
            models_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "models"))
        self.models_dir = models_dir
        self.preprocessor = DataPreprocessor()
        self.preprocessor.load(os.path.join(models_dir, "preprocessor.json"))
        self.model_manager = SportsInjuryModelManager()
        self.model_manager.load(models_dir)

    def generate_recommendations(self, athlete_data, ensemble_prob):
        """Generates evidence-based sports science recommendations based on athlete risk factors."""
        tips = []
        training_hours = float(athlete_data.get("Training_Hours_Per_Week", 15))
        fatigue = int(athlete_data.get("Fatigue_Score", 5))
        sleep = float(athlete_data.get("Sleep_Hours", 7))
        warmup = int(athlete_data.get("Warmup_Duration_Min", 15))
        hydration = float(athlete_data.get("Hydration_Level_Liters", 2.5))
        recovery = int(athlete_data.get("Recovery_Days", 2))
        soreness = int(athlete_data.get("Muscle_Soreness", 4))
        prev_injuries = int(athlete_data.get("Previous_Injuries", 0))

        if training_hours > 22:
            tips.append({
                "factor": "High Training Load",
                "severity": "high",
                "message": f"Weekly training volume ({training_hours} hrs) is high. Implement a 15-20% deload week to avoid acute-to-chronic workload spikes."
            })
        if fatigue >= 7:
            tips.append({
                "factor": "Elevated Fatigue Score",
                "severity": "high",
                "message": f"Reported fatigue ({fatigue}/10) severely impairs neuromuscular control. Introduce active recovery or light swimming/mobility."
            })
        if sleep < 7.0:
            tips.append({
                "factor": "Sleep Deprivation",
                "severity": "medium",
                "message": f"Averaging {sleep}h sleep per night. Target 8-9 hours to optimize tissue regeneration and growth hormone secretion."
            })
        if warmup < 15:
            tips.append({
                "factor": "Insufficient Warmup",
                "severity": "medium",
                "message": f"Warmup duration ({warmup} min) is below optimal. Perform dynamic stretching, activation drills, and sport-specific warmups for >= 15 min."
            })
        if hydration < 2.5:
            tips.append({
                "factor": "Sub-optimal Hydration",
                "severity": "low",
                "message": f"Daily fluid intake ({hydration} L) should be increased to 3.0+ L with electrolyte replenishment to avoid muscle cramping and strain."
            })
        if recovery <= 1:
            tips.append({
                "factor": "Insufficient Rest Days",
                "severity": "high",
                "message": f"Only {recovery} recovery day(s) per week. Ensure at least 2 full rest/light recovery days to facilitate tendon and ligament recovery."
            })
        if soreness >= 7:
            tips.append({
                "factor": "Severe Muscle Soreness",
                "severity": "high",
                "message": f"Soreness ({soreness}/10) indicates high micro-trauma. Utilize myofascial release, cryotherapy, or contrast baths."
            })
        if prev_injuries >= 2:
            tips.append({
                "factor": "Prior Injury History",
                "severity": "medium",
                "message": f"History of {prev_injuries} previous injuries increases recurrent vulnerability. Continue targeted physical therapy and joint stabilization."
            })

        if not tips:
            tips.append({
                "factor": "Optimal Athletic Balance",
                "severity": "good",
                "message": "Athlete metrics reflect excellent balance between training intensity, recovery, and hydration. Maintain current regimen!"
            })

        return tips

    def predict(self, athlete_data):
        scaled_vec = self.preprocessor.transform_single(athlete_data)
        prediction_result = self.model_manager.predict_single(scaled_vec)
        ensemble_score = prediction_result["ensemble"]["risk_score_percent"]
        recommendations = self.generate_recommendations(athlete_data, ensemble_score)

        return {
            "athlete_input": athlete_data,
            "predictions": prediction_result,
            "recommendations": recommendations,
            "metrics_summary": self.model_manager.metrics
        }

if __name__ == "__main__":
    predictor = InjuryPredictor()
    sample_athlete = {
        "Age": 24,
        "Gender": "Male",
        "Sport": "Soccer",
        "BMI": 23.4,
        "Training_Hours_Per_Week": 26.0,
        "Previous_Injuries": 2,
        "Fatigue_Score": 8,
        "Sleep_Hours": 5.5,
        "Warmup_Duration_Min": 10,
        "Hydration_Level_Liters": 2.0,
        "Training_Intensity": "High",
        "Recovery_Days": 1,
        "Muscle_Soreness": 7
    }
    result = predictor.predict(sample_athlete)
    print("\nSAMPLE PREDICTION OUTPUT:")
    print(json.dumps(result, indent=2))
