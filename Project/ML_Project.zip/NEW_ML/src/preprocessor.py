"""
Data Preprocessing & Feature Engineering Module
Handles:
- CSV Loading & Parsing
- Categorical One-Hot Encoding
- Z-Score Feature Standardization (Mean & Standard Deviation scaling)
- Stratified Train-Test Split (80/20)
- Model-ready feature matrix generation & persistence
"""

import csv
import json
import math
import os
import random

class DataPreprocessor:
    def __init__(self):
        self.num_features = [
            "Age",
            "BMI",
            "Training_Hours_Per_Week",
            "Previous_Injuries",
            "Fatigue_Score",
            "Sleep_Hours",
            "Warmup_Duration_Min",
            "Hydration_Level_Liters",
            "Recovery_Days",
            "Muscle_Soreness"
        ]
        self.cat_features = {
            "Gender": ["Male", "Female"],
            "Sport": ["Basketball", "Cricket", "Football", "Rugby", "Running", "Soccer", "Tennis"],
            "Training_Intensity": ["Low", "Medium", "High"]
        }
        self.feature_names = []
        self.scaler_means = []
        self.scaler_stds = []
        self._build_feature_names()

    def _build_feature_names(self):
        self.feature_names = list(self.num_features)
        for cat_col, categories in self.cat_features.items():
            for cat_val in categories:
                self.feature_names.append(f"{cat_col}_{cat_val}")

    def load_csv(self, file_path):
        records = []
        with open(file_path, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                records.append(row)
        return records

    def row_to_raw_vector(self, row):
        """Converts a dict of athlete attributes into a numeric vector before scaling."""
        vector = []
        # Numerical features
        for nf in self.num_features:
            val = float(row.get(nf, 0.0))
            vector.append(val)
            
        # Categorical one-hot features
        for cat_col, categories in self.cat_features.items():
            curr_val = str(row.get(cat_col, "")).strip()
            for cat_val in categories:
                vector.append(1.0 if curr_val == cat_val else 0.0)
                
        return vector

    def fit_transform(self, records):
        """Fits mean/std scalers on numeric features and transforms all records."""
        X_raw = []
        y = []
        for r in records:
            X_raw.append(self.row_to_raw_vector(r))
            y.append(int(r["Injury_Risk"]))

        n_samples = len(X_raw)
        n_features = len(self.feature_names)

        # Calculate mean and std for each feature
        self.scaler_means = [0.0] * n_features
        self.scaler_stds = [1.0] * n_features

        # Compute means
        for j in range(n_features):
            col_vals = [X_raw[i][j] for i in range(n_samples)]
            col_mean = sum(col_vals) / n_samples
            self.scaler_means[j] = col_mean

            # Standard deviation
            variance = sum((x - col_mean) ** 2 for x in col_vals) / max(1, n_samples - 1)
            col_std = math.sqrt(variance)
            # Avoid division by zero for dummy or constant columns
            self.scaler_stds[j] = col_std if col_std > 1e-7 else 1.0

        # Only scale the numeric features (first len(self.num_features)), leave one-hot binary columns as 0/1 or standardized
        X_scaled = []
        for i in range(n_samples):
            scaled_row = []
            for j in range(n_features):
                if j < len(self.num_features):
                    # Z-score standardization
                    scaled_val = (X_raw[i][j] - self.scaler_means[j]) / self.scaler_stds[j]
                    scaled_row.append(round(scaled_val, 6))
                else:
                    # One-hot encoded feature kept as 0.0 / 1.0
                    scaled_row.append(X_raw[i][j])
            X_scaled.append(scaled_row)

        return X_scaled, y

    def transform_single(self, input_dict):
        """Standardizes a single input dictionary for runtime model prediction."""
        raw_vec = self.row_to_raw_vector(input_dict)
        scaled_vec = []
        for j in range(len(raw_vec)):
            if j < len(self.num_features):
                scaled_val = (raw_vec[j] - self.scaler_means[j]) / self.scaler_stds[j]
                scaled_vec.append(scaled_val)
            else:
                scaled_vec.append(raw_vec[j])
        return scaled_vec

    def stratified_train_test_split(self, X, y, test_size=0.2, seed=42):
        random.seed(seed)
        class_0_idx = [i for i, label in enumerate(y) if label == 0]
        class_1_idx = [i for i, label in enumerate(y) if label == 1]

        random.shuffle(class_0_idx)
        random.shuffle(class_1_idx)

        test_0_count = int(round(len(class_0_idx) * test_size))
        test_1_count = int(round(len(class_1_idx) * test_size))

        test_indices = class_0_idx[:test_0_count] + class_1_idx[:test_1_count]
        train_indices = class_0_idx[test_0_count:] + class_1_idx[test_1_count:]

        random.shuffle(train_indices)
        random.shuffle(test_indices)

        X_train = [X[i] for i in train_indices]
        y_train = [y[i] for i in train_indices]
        X_test = [X[i] for i in test_indices]
        y_test = [y[i] for i in test_indices]

        return X_train, X_test, y_train, y_test

    def save(self, filepath):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        data = {
            "num_features": self.num_features,
            "cat_features": self.cat_features,
            "feature_names": self.feature_names,
            "scaler_means": self.scaler_means,
            "scaler_stds": self.scaler_stds
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def load(self, filepath):
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.num_features = data["num_features"]
        self.cat_features = data["cat_features"]
        self.feature_names = data["feature_names"]
        self.scaler_means = data["scaler_means"]
        self.scaler_stds = data["scaler_stds"]
