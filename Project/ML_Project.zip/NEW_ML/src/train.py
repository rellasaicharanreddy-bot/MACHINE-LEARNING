"""
Training Pipeline for Sports Injury Risk Prediction
Executes full model training, evaluation, and serialization for:
1. Random Forest Classifier
2. Support Vector Machine (SVM with RBF Kernel)
"""

import os
import sys

# Ensure local src directory is on sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from dataset_generator import generate_sports_injury_dataset
from preprocessor import DataPreprocessor
from models import SportsInjuryModelManager

def run_training_pipeline():
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    data_path = os.path.join(project_root, "data", "sports_injury_dataset.csv")
    models_dir = os.path.join(project_root, "models")
    preprocessor_path = os.path.join(models_dir, "preprocessor.json")

    # Step 1: Verify / Generate Dataset
    if not os.path.exists(data_path):
        print("[Pipeline] Dataset not found. Generating fresh clinical dataset...")
        generate_sports_injury_dataset(data_path, num_samples=1500)
    else:
        print(f"[Pipeline] Found existing dataset at: {data_path}")

    # Step 2: Data Preprocessing
    print("[Pipeline] Preprocessing data and creating feature matrices...")
    preprocessor = DataPreprocessor()
    records = preprocessor.load_csv(data_path)
    X, y = preprocessor.fit_transform(records)
    preprocessor.save(preprocessor_path)
    print(f"[Pipeline] Preprocessor saved with {len(preprocessor.feature_names)} features.")

    # Step 3: Stratified Train/Test Split (80/20)
    X_train, X_test, y_train, y_test = preprocessor.stratified_train_test_split(X, y, test_size=0.2, seed=42)
    print(f"[Pipeline] Training samples: {len(X_train)}, Testing samples: {len(X_test)}")

    # Step 4: Model Training and Evaluation
    manager = SportsInjuryModelManager()
    metrics = manager.train_models(X_train, y_train, X_test, y_test, preprocessor.feature_names)

    # Step 5: Save Models & Artifacts
    manager.save(models_dir)
    print("\n[Pipeline] Training pipeline successfully completed!")
    return metrics

if __name__ == "__main__":
    run_training_pipeline()
