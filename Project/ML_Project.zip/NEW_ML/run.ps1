Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  SPORTS INJURY RISK PREDICTION (RANDOM FOREST & SVM)" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Cyan

$modelsDir = Join-Path $PSScriptRoot "models"
$metricsFile = Join-Path $modelsDir "metrics.json"

if (-not (Test-Path $metricsFile)) {
    Write-Host "[Setup] Training models..." -ForegroundColor Green
    python (Join-Path $PSScriptRoot "src\train.py")
}

Write-Host "[Starting] Opening browser at http://localhost:5000 ..." -ForegroundColor Green
Start-Process "http://localhost:5000"

python (Join-Path $PSScriptRoot "app.py")
