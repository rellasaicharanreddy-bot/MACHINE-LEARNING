"""
Sports Injury Risk Prediction Web Application & REST API
Built with Python's high-performance standard HTTP server with dual Flask fallback.
Zero external server dependencies required - runs immediately on any system.
"""

import http.server
import socketserver
import json
import urllib.parse
import os
import sys

# Add src to sys.path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from predict import InjuryPredictor

PORT = 5000
project_dir = os.path.dirname(os.path.abspath(__file__))
predictor = InjuryPredictor(os.path.join(project_dir, "models"))

PRESET_ATHLETES = {
    "high_risk": {
        "name": "Overworked Soccer Midfielder (High Risk)",
        "data": {
            "Age": 24,
            "Gender": "Male",
            "Sport": "Soccer",
            "BMI": 24.2,
            "Training_Hours_Per_Week": 28.0,
            "Previous_Injuries": 2,
            "Fatigue_Score": 8,
            "Sleep_Hours": 5.5,
            "Warmup_Duration_Min": 10,
            "Hydration_Level_Liters": 2.0,
            "Training_Intensity": "High",
            "Recovery_Days": 1,
            "Muscle_Soreness": 8
        }
    },
    "low_risk": {
        "name": "Well-Balanced Distance Runner (Low Risk)",
        "data": {
            "Age": 27,
            "Gender": "Female",
            "Sport": "Running",
            "BMI": 21.0,
            "Training_Hours_Per_Week": 14.0,
            "Previous_Injuries": 0,
            "Fatigue_Score": 3,
            "Sleep_Hours": 8.5,
            "Warmup_Duration_Min": 22,
            "Hydration_Level_Liters": 3.5,
            "Training_Intensity": "Medium",
            "Recovery_Days": 3,
            "Muscle_Soreness": 3
        }
    },
    "moderate_risk": {
        "name": "Rugby Forward in Pre-Season (Moderate Risk)",
        "data": {
            "Age": 29,
            "Gender": "Male",
            "Sport": "Rugby",
            "BMI": 28.5,
            "Training_Hours_Per_Week": 20.0,
            "Previous_Injuries": 1,
            "Fatigue_Score": 6,
            "Sleep_Hours": 6.8,
            "Warmup_Duration_Min": 15,
            "Hydration_Level_Liters": 2.8,
            "Training_Intensity": "High",
            "Recovery_Days": 2,
            "Muscle_Soreness": 6
        }
    }
}

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports Injury Risk Prediction | Random Forest & SVM</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #0b0f19; color: #f1f5f9; }
        .glass-panel { background: rgba(17, 24, 39, 0.75); backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.08); }
        .glass-card { background: rgba(30, 41, 59, 0.65); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.06); }
        .glow-accent { box-shadow: 0 0 25px -5px rgba(59, 130, 246, 0.4); }
        .glow-emerald { box-shadow: 0 0 25px -5px rgba(16, 185, 129, 0.35); }
        .glow-amber { box-shadow: 0 0 25px -5px rgba(245, 158, 11, 0.35); }
        .glow-rose { box-shadow: 0 0 25px -5px rgba(239, 68, 68, 0.35); }
    </style>
</head>
<body class="min-h-screen">
    <!-- Top Navbar -->
    <header class="border-b border-slate-800 bg-slate-900/80 sticky top-0 z-50 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                </div>
                <div>
                    <h1 class="font-bold text-lg text-white leading-tight">Athletix<span class="text-blue-500">ML</span></h1>
                    <p class="text-xs text-slate-400">Sports Injury Risk Prediction &amp; Prevention</p>
                </div>
            </div>
            <div class="flex items-center space-x-3">
                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    <span class="w-2 h-2 mr-2 bg-emerald-400 rounded-full animate-pulse"></span>
                    RF &amp; SVM Dual Engine Active
                </span>
                <a href="#models-comparison" class="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition">
                    View Model Benchmarks
                </a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        <!-- Hero Header -->
        <div class="glass-panel rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div class="space-y-2 max-w-2xl">
                <div class="inline-block px-3 py-0.5 rounded-md text-xs font-semibold uppercase tracking-wider bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    Sports Biomechanics &amp; Machine Learning
                </div>
                <h2 class="text-2xl sm:text-3xl font-extrabold text-white">
                    Athlete Injury Risk Assessment System
                </h2>
                <p class="text-sm text-slate-400 leading-relaxed">
                    Evaluates workload spikes, neuromuscular fatigue, prior injuries, and sleep deficits using 
                    <span class="text-blue-400 font-semibold">Random Forest</span> and 
                    <span class="text-indigo-400 font-semibold">Support Vector Machine (RBF Kernel)</span> classifiers to prevent soft-tissue injuries.
                </p>
            </div>
            <!-- Preset Quick Loaders -->
            <div class="flex flex-col sm:flex-row md:flex-col gap-2 w-full md:w-auto">
                <span class="text-xs text-slate-400 font-medium">Quick Test Presets:</span>
                <div class="flex flex-wrap gap-2">
                    <button onclick="loadPreset('high_risk')" class="text-xs bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 px-3 py-1.5 rounded-lg font-medium transition">
                        High Risk Athlete
                    </button>
                    <button onclick="loadPreset('moderate_risk')" class="text-xs bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-lg font-medium transition">
                        Moderate Risk Athlete
                    </button>
                    <button onclick="loadPreset('low_risk')" class="text-xs bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-lg font-medium transition">
                        Low Risk Athlete
                    </button>
                </div>
            </div>
        </div>

        <!-- Two Column Layout: Form & Results -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <!-- Input Form (7 cols) -->
            <div class="lg:col-span-7 glass-panel rounded-2xl p-6 sm:p-7 space-y-6">
                <div class="flex items-center justify-between border-b border-slate-800 pb-4">
                    <div>
                        <h3 class="font-bold text-lg text-white">Athlete Assessment Metrics</h3>
                        <p class="text-xs text-slate-400">Adjust physiological, training load, and recovery indicators</p>
                    </div>
                    <button type="button" onclick="resetForm()" class="text-xs text-slate-400 hover:text-slate-200">
                        Reset Defaults
                    </button>
                </div>

                <form id="prediction-form" class="space-y-5">
                    
                    <!-- Basic Info Row -->
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">Athlete Age</label>
                            <input type="number" id="Age" name="Age" min="15" max="45" value="23" required
                                class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">Gender</label>
                            <select id="Gender" name="Gender" class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">Sport</label>
                            <select id="Sport" name="Sport" class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                                <option value="Soccer">Soccer</option>
                                <option value="Football">Football</option>
                                <option value="Basketball">Basketball</option>
                                <option value="Running">Running</option>
                                <option value="Tennis">Tennis</option>
                                <option value="Rugby">Rugby</option>
                                <option value="Cricket">Cricket</option>
                            </select>
                        </div>
                    </div>

                    <!-- Workload & Physique Row -->
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">BMI (Body Mass Index)</label>
                            <input type="number" step="0.1" id="BMI" name="BMI" min="17" max="38" value="23.8" required
                                class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">Training Hours / Week</label>
                            <input type="number" step="0.5" id="Training_Hours_Per_Week" name="Training_Hours_Per_Week" min="4" max="40" value="22.0" required
                                class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">Previous Injuries</label>
                            <select id="Previous_Injuries" name="Previous_Injuries" class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                                <option value="0">0 (No history)</option>
                                <option value="1">1 Injury</option>
                                <option value="2">2 Injuries</option>
                                <option value="3">3 Injuries</option>
                                <option value="4">4+ Injuries</option>
                            </select>
                        </div>
                    </div>

                    <!-- Sliders Section -->
                    <div class="space-y-4 pt-2 border-t border-slate-800">
                        
                        <!-- Fatigue Slider -->
                        <div>
                            <div class="flex justify-between items-center text-xs mb-1">
                                <span class="font-semibold text-slate-300">Fatigue Score (Neuromuscular Load)</span>
                                <span id="val_Fatigue_Score" class="font-bold text-blue-400">7 / 10</span>
                            </div>
                            <input type="range" id="Fatigue_Score" name="Fatigue_Score" min="1" max="10" value="7"
                                oninput="document.getElementById('val_Fatigue_Score').innerText = this.value + ' / 10'"
                                class="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500">
                        </div>

                        <!-- Muscle Soreness Slider -->
                        <div>
                            <div class="flex justify-between items-center text-xs mb-1">
                                <span class="font-semibold text-slate-300">Muscle Soreness (DOMS Rating)</span>
                                <span id="val_Muscle_Soreness" class="font-bold text-indigo-400">6 / 10</span>
                            </div>
                            <input type="range" id="Muscle_Soreness" name="Muscle_Soreness" min="1" max="10" value="6"
                                oninput="document.getElementById('val_Muscle_Soreness').innerText = this.value + ' / 10'"
                                class="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500">
                        </div>

                        <!-- Sleep Hours Slider -->
                        <div>
                            <div class="flex justify-between items-center text-xs mb-1">
                                <span class="font-semibold text-slate-300">Sleep Duration</span>
                                <span id="val_Sleep_Hours" class="font-bold text-emerald-400">6.0 hrs / night</span>
                            </div>
                            <input type="range" id="Sleep_Hours" name="Sleep_Hours" min="4" max="10" step="0.5" value="6.0"
                                oninput="document.getElementById('val_Sleep_Hours').innerText = this.value + ' hrs / night'"
                                class="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500">
                        </div>

                        <!-- Warmup Slider -->
                        <div>
                            <div class="flex justify-between items-center text-xs mb-1">
                                <span class="font-semibold text-slate-300">Warmup &amp; Mobility Duration</span>
                                <span id="val_Warmup_Duration_Min" class="font-bold text-cyan-400">12 mins</span>
                            </div>
                            <input type="range" id="Warmup_Duration_Min" name="Warmup_Duration_Min" min="0" max="35" step="1" value="12"
                                oninput="document.getElementById('val_Warmup_Duration_Min').innerText = this.value + ' mins'"
                                class="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500">
                        </div>

                        <!-- Hydration Slider -->
                        <div>
                            <div class="flex justify-between items-center text-xs mb-1">
                                <span class="font-semibold text-slate-300">Daily Hydration Intake</span>
                                <span id="val_Hydration_Level_Liters" class="font-bold text-sky-400">2.2 L / day</span>
                            </div>
                            <input type="range" id="Hydration_Level_Liters" name="Hydration_Level_Liters" min="1.0" max="5.0" step="0.1" value="2.2"
                                oninput="document.getElementById('val_Hydration_Level_Liters').innerText = this.value + ' L / day'"
                                class="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500">
                        </div>
                    </div>

                    <!-- Intensity & Recovery Row -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">Training Intensity</label>
                            <select id="Training_Intensity" name="Training_Intensity" class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                                <option value="High" selected>High (Match / Heavy Conditioning)</option>
                                <option value="Medium">Medium (Standard Tactical)</option>
                                <option value="Low">Low (Active Recovery / Technical)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-300 mb-1.5">Weekly Recovery Days</label>
                            <select id="Recovery_Days" name="Recovery_Days" class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition">
                                <option value="0">0 Days (No rest)</option>
                                <option value="1" selected>1 Day</option>
                                <option value="2">2 Days (Standard)</option>
                                <option value="3">3 Days</option>
                                <option value="4">4+ Days</option>
                            </select>
                        </div>
                    </div>

                    <!-- Predict Action Button -->
                    <button type="submit" id="btn-predict"
                        class="w-full mt-4 py-3.5 px-6 rounded-xl font-bold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 shadow-lg shadow-indigo-500/25 transition-all transform active:scale-[0.99] flex items-center justify-center space-x-2">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Compute Injury Risk Prediction</span>
                    </button>
                </form>
            </div>

            <!-- Prediction Results & Recommendations (5 cols) -->
            <div class="lg:col-span-5 space-y-6">
                
                <!-- Main Risk Result Card -->
                <div id="result-container" class="glass-panel rounded-2xl p-6 sm:p-7 space-y-6 transition-all duration-300">
                    <div class="border-b border-slate-800 pb-3 flex justify-between items-center">
                        <h3 class="font-bold text-base text-white">Risk Analysis Output</h3>
                        <span id="badge-status" class="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-slate-800 text-slate-400">
                            Awaiting Assessment
                        </span>
                    </div>

                    <!-- Consensus Risk Gauge -->
                    <div class="flex flex-col items-center justify-center py-4 text-center">
                        <div class="relative w-40 h-40 flex items-center justify-center">
                            <svg class="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                                <path class="text-slate-800" stroke-width="3.5" stroke="currentColor" fill="none"
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                <path id="gauge-circle" class="text-blue-500 transition-all duration-700 ease-out" stroke-dasharray="0, 100" stroke-width="3.5" stroke-linecap="round" stroke="currentColor" fill="none"
                                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            </svg>
                            <div class="absolute flex flex-col items-center justify-center">
                                <span id="risk-score-value" class="text-4xl font-extrabold text-white">--%</span>
                                <span class="text-xs uppercase tracking-widest text-slate-400 font-medium">Risk Score</span>
                            </div>
                        </div>
                        <p id="risk-category-text" class="mt-3 text-lg font-bold text-slate-200">Submit form to predict</p>
                    </div>

                    <!-- Model Head-to-Head Comparison -->
                    <div class="grid grid-cols-2 gap-4 pt-4 border-t border-slate-800">
                        <div class="glass-card rounded-xl p-4 text-center space-y-1">
                            <span class="text-xs font-semibold text-slate-400">Random Forest</span>
                            <div id="rf-prediction-label" class="text-sm font-bold text-slate-300">--</div>
                            <div id="rf-prob" class="text-xs text-blue-400 font-medium">Prob: --%</div>
                        </div>
                        <div class="glass-card rounded-xl p-4 text-center space-y-1">
                            <span class="text-xs font-semibold text-slate-400">Support Vector (SVM)</span>
                            <div id="svm-prediction-label" class="text-sm font-bold text-slate-300">--</div>
                            <div id="svm-prob" class="text-xs text-indigo-400 font-medium">Prob: --%</div>
                        </div>
                    </div>

                    <!-- Evidence-based Recommendations -->
                    <div class="pt-4 border-t border-slate-800 space-y-3">
                        <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center">
                            <svg class="w-4 h-4 mr-1.5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                            Clinical Prevention Recommendations
                        </h4>
                        <div id="recommendations-list" class="space-y-2 text-xs text-slate-300 max-h-64 overflow-y-auto pr-1">
                            <p class="text-slate-500 italic">Recommendations will automatically populate after injury risk calculation.</p>
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <!-- Section: Models Performance & Scientific Benchmarks -->
        <section id="models-comparison" class="glass-panel rounded-2xl p-6 sm:p-8 space-y-6">
            <div class="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                    <h3 class="text-xl font-bold text-white">Random Forest vs. SVM Comparative Evaluation</h3>
                    <p class="text-xs text-slate-400">Cross-validated benchmark on 1,500 athlete records (80% Train / 20% Test)</p>
                </div>
                <div class="text-xs text-slate-400 bg-slate-900/60 px-3 py-1.5 rounded-lg border border-slate-800">
                    Target: Binary Injury Classification (0 = Low Risk, 1 = High Risk)
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                
                <!-- Metrics Table (6 cols) -->
                <div class="lg:col-span-6 overflow-x-auto">
                    <table class="w-full text-left text-xs border-collapse">
                        <thead>
                            <tr class="border-b border-slate-800 text-slate-400">
                                <th class="py-3 px-4 font-semibold uppercase tracking-wider">Evaluation Metric</th>
                                <th class="py-3 px-4 font-semibold text-blue-400">Random Forest</th>
                                <th class="py-3 px-4 font-semibold text-indigo-400">Support Vector (SVM)</th>
                                <th class="py-3 px-4 font-semibold text-emerald-400">Superior Model</th>
                            </tr>
                        </thead>
                        <tbody id="metrics-table-body" class="divide-y divide-slate-800/60 font-medium">
                            <tr><td colspan="4" class="py-4 text-center text-slate-500">Loading benchmark metrics...</td></tr>
                        </tbody>
                    </table>
                </div>

                <!-- Feature Importance Chart (6 cols) -->
                <div class="lg:col-span-6 bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                    <h4 class="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Random Forest Top Feature Importances (Gini Impurity)</h4>
                    <div class="h-64 relative">
                        <canvas id="featuresChart"></canvas>
                    </div>
                </div>

            </div>
        </section>

    </main>

    <!-- Footer -->
    <footer class="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
        <p>Sports Injury Risk Prediction System &bull; Machine Learning Project (Random Forest &amp; SVM)</p>
        <p class="mt-1">Trained on multi-factorial biomechanical &amp; training workload indicators.</p>
    </footer>

    <!-- Client-side script -->
    <script>
        const PRESETS = {presets_json};
        let metricsData = null;
        let chartInstance = null;

        function loadPreset(key) {
            const preset = PRESETS[key];
            if (!preset) return;
            const data = preset.data;
            for (const [k, v] of Object.entries(data)) {
                const el = document.getElementById(k);
                if (el) {
                    el.value = v;
                    const valEl = document.getElementById('val_' + k);
                    if (valEl) {
                        if (k === 'Sleep_Hours') valEl.innerText = v + ' hrs / night';
                        else if (k === 'Warmup_Duration_Min') valEl.innerText = v + ' mins';
                        else if (k === 'Hydration_Level_Liters') valEl.innerText = v + ' L / day';
                        else valEl.innerText = v + ' / 10';
                    }
                }
            }
            // Trigger prediction automatically
            executePrediction();
        }

        function resetForm() {
            document.getElementById('prediction-form').reset();
            document.getElementById('val_Fatigue_Score').innerText = '7 / 10';
            document.getElementById('val_Muscle_Soreness').innerText = '6 / 10';
            document.getElementById('val_Sleep_Hours').innerText = '6.0 hrs / night';
            document.getElementById('val_Warmup_Duration_Min').innerText = '12 mins';
            document.getElementById('val_Hydration_Level_Liters').innerText = '2.2 L / day';
        }

        async function fetchMetrics() {
            try {
                const res = await fetch('/api/metrics');
                metricsData = await res.json();
                renderMetricsTable(metricsData);
                renderFeatureChart(metricsData);
            } catch (err) {
                console.error("Failed to load metrics:", err);
            }
        }

        function renderMetricsTable(data) {
            const rf = data.random_forest;
            const svm = data.svm;
            const tbody = document.getElementById('metrics-table-body');
            
            const rows = [
                { name: 'Model Accuracy', rf: rf.accuracy + '%', svm: svm.accuracy + '%', winner: svm.accuracy >= rf.accuracy ? 'SVM' : 'Random Forest' },
                { name: 'Precision', rf: rf.precision + '%', svm: svm.precision + '%', winner: svm.precision >= rf.precision ? 'SVM' : 'Random Forest' },
                { name: 'Recall / Sensitivity', rf: rf.recall + '%', svm: svm.recall + '%', winner: svm.recall >= rf.recall ? 'SVM' : 'Random Forest' },
                { name: 'F1-Score (Harmonic Mean)', rf: rf.f1_score + '%', svm: svm.f1_score + '%', winner: svm.f1_score >= rf.f1_score ? 'SVM' : 'Random Forest' },
                { name: 'ROC-AUC Score', rf: rf.roc_auc + '%', svm: svm.roc_auc + '%', winner: svm.roc_auc >= rf.roc_auc ? 'SVM' : 'Random Forest' }
            ];

            tbody.innerHTML = rows.map(r => `
                <tr class="hover:bg-slate-800/40 transition">
                    <td class="py-3 px-4 text-slate-300 font-semibold">${r.name}</td>
                    <td class="py-3 px-4 text-blue-400">${r.rf}</td>
                    <td class="py-3 px-4 text-indigo-400">${r.svm}</td>
                    <td class="py-3 px-4">
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            ${r.winner}
                        </span>
                    </td>
                </tr>
            `).join('');
        }

        function renderFeatureChart(data) {
            const fi = data.random_forest.feature_importances;
            if (!fi) return;
            
            // Sort top 8 features
            const sorted = Object.entries(fi).sort((a, b) => b[1] - a[1]).slice(0, 8);
            const labels = sorted.map(s => s[0].replace(/_/g, ' '));
            const values = sorted.map(s => Math.round(s[1] * 1000) / 10);

            const ctx = document.getElementById('featuresChart').getContext('2d');
            if (chartInstance) chartInstance.destroy();

            chartInstance = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Relative Importance (%)',
                        data: values,
                        backgroundColor: 'rgba(59, 130, 246, 0.75)',
                        borderColor: 'rgba(99, 102, 241, 1)',
                        borderWidth: 1,
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        x: {
                            ticks: { color: '#94a3b8', font: { size: 10 } },
                            grid: { display: false }
                        },
                        y: {
                            ticks: { color: '#94a3b8', font: { size: 10 } },
                            grid: { color: 'rgba(255,255,255,0.05)' }
                        }
                    }
                }
            });
        }

        async function executePrediction() {
            const form = document.getElementById('prediction-form');
            const formData = new FormData(form);
            const payload = {};
            formData.forEach((value, key) => {
                if (['Age', 'BMI', 'Training_Hours_Per_Week', 'Previous_Injuries', 'Fatigue_Score', 'Sleep_Hours', 'Warmup_Duration_Min', 'Hydration_Level_Liters', 'Recovery_Days', 'Muscle_Soreness'].includes(key)) {
                    payload[key] = parseFloat(value);
                } else {
                    payload[key] = value;
                }
            });

            try {
                const res = await fetch('/api/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const result = await res.json();
                updateUIWithResults(result);
            } catch (err) {
                alert("Error making prediction: " + err);
            }
        }

        function updateUIWithResults(result) {
            const preds = result.predictions;
            const ensemble = preds.ensemble;
            const rf = preds.random_forest;
            const svm = preds.svm;

            // Update Circle Gauge
            const circle = document.getElementById('gauge-circle');
            circle.setAttribute('stroke-dasharray', `${ensemble.risk_score_percent}, 100`);
            circle.style.stroke = ensemble.risk_color;

            // Score & Badge
            document.getElementById('risk-score-value').innerText = ensemble.risk_score_percent + '%';
            document.getElementById('risk-category-text').innerText = ensemble.risk_category;
            document.getElementById('risk-category-text').style.color = ensemble.risk_color;

            const badge = document.getElementById('badge-status');
            badge.innerText = ensemble.risk_category;
            badge.style.backgroundColor = ensemble.risk_color + '22';
            badge.style.color = ensemble.risk_color;
            badge.style.borderColor = ensemble.risk_color + '55';

            // RF Box
            document.getElementById('rf-prediction-label').innerText = rf.label;
            document.getElementById('rf-prediction-label').className = 'text-sm font-bold ' + (rf.prediction === 1 ? 'text-rose-400' : 'text-emerald-400');
            document.getElementById('rf-prob').innerText = 'Probability: ' + rf.probability + '%';

            // SVM Box
            document.getElementById('svm-prediction-label').innerText = svm.label;
            document.getElementById('svm-prediction-label').className = 'text-sm font-bold ' + (svm.prediction === 1 ? 'text-rose-400' : 'text-emerald-400');
            document.getElementById('svm-prob').innerText = 'Probability: ' + svm.probability + '%';

            // Recommendations List
            const recContainer = document.getElementById('recommendations-list');
            if (result.recommendations && result.recommendations.length > 0) {
                recContainer.innerHTML = result.recommendations.map(r => {
                    const colorClass = r.severity === 'high' ? 'border-rose-500/40 bg-rose-500/10 text-rose-300' :
                                       (r.severity === 'medium' ? 'border-amber-500/40 bg-amber-500/10 text-amber-300' :
                                       (r.severity === 'good' ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300' : 'border-blue-500/40 bg-blue-500/10 text-blue-300'));
                    return `
                        <div class="p-2.5 rounded-lg border ${colorClass} transition">
                            <span class="font-bold block mb-0.5">${r.factor}</span>
                            <span>${r.message}</span>
                        </div>
                    `;
                }).join('');
            }
        }

        document.getElementById('prediction-form').addEventListener('submit', function(e) {
            e.preventDefault();
            executePrediction();
        });

        // Initialize on load
        window.addEventListener('DOMContentLoaded', () => {
            fetchMetrics();
            executePrediction();
        });
    </script>
</body>
</html>
"""

class SportsInjuryRequestHandler(http.server.BaseHTTPRequestHandler):
    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/" or path == "/index.html":
            rendered = HTML_TEMPLATE.replace("{presets_json}", json.dumps(PRESET_ATHLETES))
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(rendered.encode("utf-8"))

        elif path == "/api/status":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._send_cors_headers()
            self.end_headers()
            status = {
                "status": "online",
                "app": "Sports Injury Risk Prediction System",
                "models": ["Random Forest", "Support Vector Machine (SVM)"],
                "features_count": len(predictor.preprocessor.feature_names)
            }
            self.wfile.write(json.dumps(status).encode("utf-8"))

        elif path == "/api/metrics":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps(predictor.model_manager.metrics).encode("utf-8"))

        elif path == "/api/presets":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps(PRESET_ATHLETES).encode("utf-8"))

        else:
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"error": "Endpoint not found"}).encode("utf-8"))

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/predict":
            content_length = int(self.headers.get("Content-Length", 0))
            post_body = self.rfile.read(content_length).decode("utf-8")
            try:
                data = json.loads(post_body)
                result = predictor.predict(data)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps(result).encode("utf-8"))
            except Exception as e:
                self.send_response(400)
                self.send_header("Content-Type", "application/json")
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))
        else:
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"error": "Endpoint not found"}).encode("utf-8"))

    def log_message(self, format, *args):
        # Clean logging format
        print(f"[AthletixML Server] {args[0]} - {args[1]} {args[2]}")


def run_server(port=PORT):
    # Allow port reuse
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", port), SportsInjuryRequestHandler) as httpd:
        print("\n" + "="*60)
        print("  ATHLETIX ML - SPORTS INJURY RISK PREDICTION SERVER")
        print("="*60)
        print(f"  > Dashboard URL:  http://localhost:{port}")
        print(f"  > API Metrics:    http://localhost:{port}/api/metrics")
        print(f"  > API Predict:    http://localhost:{port}/api/predict (POST)")
        print(f"  > Presets:        http://localhost:{port}/api/presets")
        print("="*60)
        print("  Press Ctrl+C to stop the server at any time.\n")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n[AthletixML Server] Shutting down gracefully.")
            httpd.server_close()

if __name__ == "__main__":
    port_arg = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    run_server(port_arg)
