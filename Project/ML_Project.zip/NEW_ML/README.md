# Sports Injury Risk Prediction Using Random Forest and SVM

An end-to-end Machine Learning project that assesses acute neuromuscular fatigue, biomechanical workloads, and clinical recovery indicators to predict injury susceptibility in athletes using **Random Forest** and **Support Vector Machine (SVM with RBF Kernel)** algorithms.

---

## 📌 Project Overview

- **Project Title:** Sports Injury Risk Prediction Using Random Forest and SVM
- **Domain:** Sports Medicine, Athletic Biomechanics & Predictive Healthcare
- **Algorithms Implemented:**
  1. **Random Forest Classifier (Ensemble Bagging with Gini Impurity Decision Splits)**
  2. **Support Vector Machine (Soft-Margin Dual Quadratic Optimization with RBF Kernel & Platt Sigmoid Scaling)**
- **Target Variable:** `Injury_Risk` (Binary Classification: `0 = Low Risk`, `1 = High Risk`)
- **Dataset Size:** 1,500 Multi-variate Athletic Records (1,200 Train / 300 Test Stratified Split)

---

## 📊 Dataset Features & Biomechanical Indicators

The dataset contains clinical sports science metrics across 7 major sports (*Soccer, Football, Basketball, Running, Tennis, Rugby, Cricket*):

| Feature Name | Type | Description | Range |
| :--- | :--- | :--- | :--- |
| `Athlete_ID` | Identifier | Unique athlete tracking code | ATH_0001 - ATH_1500 |
| `Age` | Numerical | Age of athlete | 17 – 36 years |
| `Gender` | Categorical | Biological gender (Male / Female) | Binary |
| `Sport` | Categorical | Specific sport discipline | 7 sports |
| `BMI` | Numerical | Body Mass Index ($kg/m^2$) | 18.5 – 34.0 |
| `Training_Hours_Per_Week` | Numerical | Cumulative training workload | 6.0 – 32.0 hrs/week |
| `Previous_Injuries` | Discrete | History of past joint/musculoskeletal injuries | 0 – 4 |
| `Fatigue_Score` | Discrete | Subjective/objective neuromuscular fatigue | 1 – 10 rating |
| `Sleep_Hours` | Numerical | Average nightly restorative sleep | 4.0 – 10.0 hrs |
| `Warmup_Duration_Min` | Discrete | Dynamic warmup & mobility duration | 0 – 35 mins |
| `Hydration_Level_Liters` | Numerical | Daily fluid intake | 1.0 – 5.0 Liters |
| `Training_Intensity` | Categorical | Session workload level (Low, Medium, High) | 3 levels |
| `Recovery_Days` | Discrete | Dedicated full rest/light recovery days per week | 0 – 4 days |
| `Muscle_Soreness` | Discrete | Delayed Onset Muscle Soreness (DOMS) scale | 1 – 10 rating |
| `Injury_Risk` | **Target** | Binary acute injury risk flag | **0 (Low) / 1 (High)** |

---

## 📈 Model Performance & Comparative Evaluation

Evaluated on the holdout test set (300 records, 20% stratified test split):

| Metric | Random Forest Classifier | Support Vector Machine (RBF Kernel) | Superior Performer |
| :--- | :---: | :---: | :---: |
| **Accuracy** | **84.67%** | **91.67%** | **SVM (+7.00%)** |
| **Precision** | **85.54%** | **91.67%** | **SVM (+6.13%)** |
| **Recall (Sensitivity)** | **67.62%** | **83.81%** | **SVM (+16.19%)** |
| **F1-Score** | **75.53%** | **87.56%** | **SVM (+12.03%)** |
| **ROC-AUC Score** | **91.87%** | **98.43%** | **SVM (+6.56%)** |

### Confusion Matrix Breakdown

#### 1. Random Forest Confusion Matrix:
- **True Negatives (TN):** 183
- **False Positives (FP):** 12
- **False Negatives (FN):** 34
- **True Positives (TP):** 71

#### 2. Support Vector Machine (SVM) Confusion Matrix:
- **True Negatives (TN):** 187
- **False Positives (FP):** 8
- **False Negatives (FN):** 17
- **True Positives (TP):** 88

### Top Feature Importances (Random Forest Gini Impurity)
1. **Muscle Soreness (DOMS):** 10.25%
2. **Neuromuscular Fatigue Score:** 10.00%
3. **Training Hours Per Week:** 9.49%
4. **Sleep Duration (Hours):** 8.48%
5. **Previous Injuries History:** 8.23%
6. **Warmup & Mobility Duration:** 7.47%
7. **Body Mass Index (BMI):** 6.96%
8. **Weekly Recovery Days:** 6.84%

---

## 🏗️ Project Architecture

```
NEW_ML/
├── data/
│   └── sports_injury_dataset.csv     # 1,500 record dataset
├── models/
│   ├── metrics.json                  # Benchmark performance metrics
│   ├── preprocessor.json             # Normalization parameters & feature mapping
│   ├── rf_model.json                 # Serialized Random Forest ensemble
│   └── svm_model.json                # Serialized SVM model & support vectors
├── src/
│   ├── dataset_generator.py          # Data synthesis & clinical correlation engine
│   ├── preprocessor.py               # Z-score standardization & One-Hot Encoding
│   ├── models.py                     # Algorithmic RF & SVM implementations
│   ├── train.py                      # Model training & comparative evaluation pipeline
│   └── predict.py                    # Inference engine & clinical recommendations
├── app.py                            # Interactive Web Dashboard & REST API
├── requirements.txt                  # Python dependencies
├── run.bat                           # One-click Windows batch launcher
├── run.ps1                           # One-click PowerShell launcher
└── README.md                         # Complete project documentation
```

---

## 🚀 How to Run the Project

### Option 1: Fast One-Click Launcher (Windows)
Double-click `run.bat` or run:
```powershell
.\run.bat
```
*(Automatically opens the interactive web dashboard at `http://localhost:5000`)*

---

### Option 2: Running via Python Terminal

1. **Train or Retrain the Models:**
   ```bash
   python src/train.py
   ```

2. **Run a Sample Prediction from Command Line:**
   ```bash
   python src/predict.py
   ```

3. **Launch the Web Dashboard & REST API:**
   ```bash
   python app.py
   ```
   Open your browser to: **`http://localhost:5000`**

---

## 🔌 REST API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/` | Web Dashboard user interface |
| `GET` | `/api/status` | Server status and active ML model verification |
| `GET` | `/api/metrics` | Model comparison, accuracy, recall, and feature importances |
| `GET` | `/api/presets` | Sample athlete presets (High Risk, Moderate Risk, Low Risk) |
| `POST` | `/api/predict` | Computes injury risk and returns clinical prevention tips |

### Sample API Request (`POST /api/predict`):
```json
{
  "Age": 24,
  "Gender": "Male",
  "Sport": "Soccer",
  "BMI": 23.4,
  "Training_Hours_Per_Week": 26.0,
  "Previous_Injuries": 2,
  "Fatigue_Score": 8,
  "Sleep_Hours": 5.5,
  "Warmup_Duration_Min": 10,
  "Hydration_Level_Liters": 2.0,
  "Training_Intensity": "High",
  "Recovery_Days": 1,
  "Muscle_Soreness": 7
}
```

### Sample API Response:
```json
{
  "predictions": {
    "random_forest": { "prediction": 1, "label": "High Risk", "probability": 96.5 },
    "svm": { "prediction": 1, "label": "High Risk", "probability": 100.0 },
    "ensemble": { "risk_score_percent": 98.1, "risk_category": "High Risk", "risk_color": "#ef4444" }
  },
  "recommendations": [
    { "factor": "High Training Load", "severity": "high", "message": "Weekly training volume is high. Implement a 15-20% deload week." },
    { "factor": "Elevated Fatigue Score", "severity": "high", "message": "Reported fatigue (8/10) severely impairs neuromuscular control." }
  ]
}
```

---

## 💡 Clinical Recommendations Engine

The system provides athlete-specific injury prevention advice:
- **Workload Deloading:** Alerts when weekly training exceeds 22 hours to prevent spikes in acute-to-chronic workload ratio (ACWR).
- **Sleep Optimization:** Prescribes 8–9 hours of sleep for cellular regeneration and collagen synthesis.
- **Warmup Protocols:** Flags sub-15 minute warmups to ensure dynamic muscle elasticity and neuromuscular activation.
- **Hydration & Recovery:** Recommends electrolyte replenishment and minimum 2 full rest/light active recovery days per week.
